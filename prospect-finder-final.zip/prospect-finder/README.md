# 🎯 Prospect Finder

**SaaS de prospection B2B propulsé par l'IA** — Next.js 14 + Supabase + Mollie + Claude AI

---

## ✨ Fonctionnalités

- 🤖 **Recherche IA** — Claude trouve des prospects qualifiés par secteur, pays et plateforme
- ✉️ **Messages personnalisés** — L'IA génère des emails/messages LinkedIn sur-mesure pour chaque prospect
- 📤 **Envoi automatique** — Envoi par email (SMTP) ou LinkedIn API
- 💳 **Paiements Mollie** — Abonnements mensuels avec renouvellement automatique
- 📊 **Tableau de bord** — Suivi en temps réel des prospects et conversions
- 🔐 **Auth Supabase** — Inscription/connexion sécurisée
- 🚀 **Prêt Vercel** — Déploiement en 1 clic

---

## 🏗️ Stack technique

| Couche       | Technologie                         |
|-------------|--------------------------------------|
| Frontend     | Next.js 14 (App Router), TypeScript  |
| Styling      | Tailwind CSS                         |
| Backend      | Next.js API Routes (serverless)      |
| Base de données | Supabase (PostgreSQL)             |
| Auth         | Supabase Auth                        |
| IA           | Anthropic Claude (claude-opus-4)     |
| Paiements    | Mollie API                           |
| Email        | Nodemailer (SMTP)                    |
| Déploiement  | Vercel                               |

---

## 🚀 Installation locale

### 1. Cloner et installer

```bash
git clone https://github.com/votre-repo/prospect-finder.git
cd prospect-finder
npm install
```

### 2. Configurer Supabase

1. Créez un projet sur [supabase.com](https://supabase.com)
2. Dans l'éditeur SQL, exécutez le fichier `supabase/migrations/001_schema.sql`
3. Activez l'authentification par email dans **Authentication → Providers**
4. Récupérez vos clés dans **Project Settings → API**

### 3. Variables d'environnement

Copiez `.env.local.example` en `.env.local` et remplissez :

```bash
cp .env.local.example .env.local
```

```env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
SUPABASE_SERVICE_ROLE_KEY=eyJ...

# Anthropic
ANTHROPIC_API_KEY=sk-ant-...

# Mollie
MOLLIE_API_KEY=live_dngP5ybNcAH9bzW64ESzpgMaznbDk4
NEXT_PUBLIC_APP_URL=https://votre-domaine.vercel.app

# Email SMTP
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=votre@gmail.com
SMTP_PASS=votre_mot_de_passe_application
SMTP_FROM="Prospect Finder <noreply@prospectfinder.io>"
```

### 4. Lancer en développement

```bash
npm run dev
```

Accès : [http://localhost:3000](http://localhost:3000)

---

## 💳 Configuration Mollie

### Webhook local (développement)

Utilisez [ngrok](https://ngrok.com) pour exposer votre serveur local :

```bash
ngrok http 3000
```

Puis configurez dans `.env.local` :
```env
NEXT_PUBLIC_APP_URL=https://xxxx.ngrok.io
```

Le webhook Mollie est automatiquement notifié à :
`https://votre-domaine.com/api/webhooks/mollie`

### Flux de paiement

```
Utilisateur clique "S'abonner"
       ↓
POST /api/subscriptions/create
       ↓
Création client Mollie + paiement "first"
       ↓
Redirection → Page paiement Mollie
       ↓
Paiement réussi → Mollie appelle webhook
       ↓
POST /api/webhooks/mollie
       ↓
Abonnement activé en BDD (status: active)
       ↓
Mandat enregistré → renouvellements automatiques
```

---

## 🚀 Déploiement Vercel

### 1. Push sur GitHub

```bash
git add .
git commit -m "Initial commit"
git push origin main
```

### 2. Importer sur Vercel

1. Allez sur [vercel.com](https://vercel.com)
2. **New Project** → Importer votre repo GitHub
3. Framework : **Next.js** (auto-détecté)

### 3. Variables d'environnement Vercel

Dans **Settings → Environment Variables**, ajoutez toutes les variables de `.env.local`.

> ⚠️ **Important** : Mettez à jour `NEXT_PUBLIC_APP_URL` avec votre vrai domaine Vercel avant de déployer.

### 4. Configurer Mollie Webhook

Dans votre [dashboard Mollie](https://my.mollie.com) :
- **Developers → Webhooks**
- URL : `https://votre-app.vercel.app/api/webhooks/mollie`

---

## 📁 Structure du projet

```
prospect-finder/
├── app/
│   ├── page.tsx                    # Landing page marketing
│   ├── auth/
│   │   ├── login/page.tsx          # Page connexion
│   │   ├── signup/page.tsx         # Page inscription
│   │   └── callback/route.ts       # Callback OAuth
│   ├── dashboard/
│   │   ├── layout.tsx              # Layout avec sidebar
│   │   ├── page.tsx                # Tableau de bord
│   │   └── settings/page.tsx       # Paramètres profil
│   ├── prospects/
│   │   ├── layout.tsx
│   │   └── page.tsx                # Liste + recherche IA
│   ├── messages/
│   │   ├── layout.tsx
│   │   └── page.tsx                # Génération + envoi messages
│   ├── billing/
│   │   ├── layout.tsx
│   │   ├── page.tsx                # Plans + gestion abonnement
│   │   └── success/page.tsx        # Page confirmation paiement
│   └── api/
│       ├── prospects/
│       │   ├── search/route.ts      # Recherche IA prospects
│       │   ├── generate-message/   # Génération message IA
│       │   └── send/route.ts       # Envoi email/LinkedIn
│       ├── subscriptions/
│       │   ├── create/route.ts     # Créer abonnement Mollie
│       │   ├── cancel/route.ts     # Annuler abonnement
│       │   └── status/route.ts     # Statut abonnement
│       └── webhooks/
│           └── mollie/route.ts     # Webhook paiements Mollie
├── components/
│   └── layout/
│       ├── Sidebar.tsx             # Navigation latérale
│       └── TopBar.tsx              # Barre du haut
├── lib/
│   ├── supabase/
│   │   ├── client.ts               # Client browser
│   │   └── server.ts               # Client server + admin
│   ├── mollie.ts                   # Intégration Mollie API
│   ├── ai.ts                       # Services IA (Anthropic)
│   ├── email.ts                    # Envoi emails SMTP
│   └── utils.ts                    # Utilitaires
├── types/index.ts                  # Types TypeScript
├── middleware.ts                   # Auth middleware
├── supabase/migrations/
│   └── 001_schema.sql              # Schéma BDD complet
└── vercel.json                     # Config déploiement
```

---

## 📊 Plans tarifaires

| Fonctionnalité          | Standard (29€/mois) | Premium (79€/mois) |
|------------------------|--------------------|--------------------|
| Prospects/mois          | 100                | 1 000              |
| Messages/mois           | 50                 | 500                |
| Recherche IA            | ✅                 | ✅                 |
| Messages IA             | ✅                 | ✅                 |
| Envoi Email             | ✅                 | ✅                 |
| Envoi LinkedIn          | ❌                 | ✅                 |
| Envoi automatique       | ❌                 | ✅                 |
| Support prioritaire     | ❌                 | ✅                 |

---

## 🔒 Sécurité

- Row Level Security (RLS) activé sur toutes les tables Supabase
- Clés API jamais exposées côté client
- Webhook Mollie validé côté serveur
- Middleware d'authentification sur toutes les routes protégées

---

## 📝 Licence

MIT © 2025 Prospect Finder
