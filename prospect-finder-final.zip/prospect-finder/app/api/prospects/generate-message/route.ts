import { createClient } from '@/lib/supabase/server';
import { NextResponse } from 'next/server';
import { aiGenerateMessage } from '@/lib/ai';

export async function POST(req: Request) {
  try {
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });

    const { data: sub } = await supabase.from('subscriptions')
      .select('*').eq('user_id', user.id).eq('status', 'active').limit(1).single();
    if (!sub) return NextResponse.json({ error: 'Abonnement requis' }, { status: 403 });

    const { prospectId, channel, objective, save } = await req.json();

    // Charger prospect
    const { data: prospect } = await supabase.from('prospects').select('*').eq('id', prospectId).eq('user_id', user.id).single();
    if (!prospect) return NextResponse.json({ error: 'Prospect introuvable' }, { status: 404 });

    // Charger profil expéditeur
    const { data: profile } = await supabase.from('profiles').select('*').eq('id', user.id).single();
    const senderName = profile?.full_name || user.email?.split('@')[0] || 'Votre équipe';

    // Générer via IA
    const message = await aiGenerateMessage({
      prospect,
      channel: channel || 'email',
      senderName,
      senderCompany: profile?.company,
      objective,
    });

    // Sauvegarder si demandé
    if (save) {
      const { data: saved } = await supabase.from('messages').insert({
        user_id: user.id,
        prospect_id: prospectId,
        channel: channel || 'email',
        subject: message.subject,
        body: message.body,
        status: 'brouillon',
      }).select().single();
      return NextResponse.json({ message, saved });
    }

    return NextResponse.json({ message });
  } catch (err: any) {
    console.error('Erreur génération message:', err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
