import { createClient } from '@/lib/supabase/server';
import { NextResponse } from 'next/server';
import { aiSearchProspects } from '@/lib/ai';

export async function POST(req: Request) {
  try {
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });

    // Vérifier abonnement actif
    const { data: sub } = await supabase.from('subscriptions')
      .select('*').eq('user_id', user.id).eq('status', 'active').limit(1).single();
    if (!sub) return NextResponse.json({ error: 'Abonnement requis pour utiliser la recherche IA' }, { status: 403 });

    const { industry, country, platform, keywords, count, campaignName } = await req.json();

    if (!industry || !country) {
      return NextResponse.json({ error: 'Secteur et pays requis' }, { status: 400 });
    }

    // Vérifier quota mensuel
    const startOfMonth = new Date(); startOfMonth.setDate(1); startOfMonth.setHours(0,0,0,0);
    const { count: monthlyCount } = await supabase.from('prospects')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', user.id)
      .gte('created_at', startOfMonth.toISOString());

    const quota = sub.plan === 'premium' ? 1000 : 100;
    if ((monthlyCount || 0) + count > quota) {
      return NextResponse.json({ error: `Quota mensuel dépassé (${quota} prospects/${sub.plan})` }, { status: 429 });
    }

    // Créer campagne
    const { data: campaign } = await supabase.from('campaigns').insert({
      user_id: user.id,
      name: campaignName || `${industry} — ${country}`,
      industry, country, platform,
      keywords: keywords || [],
      total_found: count,
    }).select().single();

    // Appel IA
    const aiProspects = await aiSearchProspects({ industry, country, platform, keywords, count });

    if (!aiProspects.length) {
      return NextResponse.json({ error: 'L\'IA n\'a pas trouvé de prospects' }, { status: 500 });
    }

    // Insérer en base
    const toInsert = aiProspects.map((p: any) => ({
      user_id: user.id,
      campaign_id: campaign?.id || null,
      full_name: p.full_name,
      email: p.email,
      company: p.company,
      job_title: p.job_title,
      linkedin_url: p.linkedin_url,
      website: p.website,
      industry: p.industry || industry,
      country: p.country || country,
      platform: p.platform || platform,
      score: p.score || Math.floor(Math.random() * 30 + 60),
      ai_summary: p.ai_summary,
      status: 'nouveau',
    }));

    const { data: inserted, error: insertErr } = await supabase
      .from('prospects').insert(toInsert).select();

    if (insertErr) throw insertErr;

    return NextResponse.json({ prospects: inserted, count: inserted?.length });
  } catch (err: any) {
    console.error('Erreur recherche prospects:', err);
    return NextResponse.json({ error: err.message || 'Erreur interne' }, { status: 500 });
  }
}
