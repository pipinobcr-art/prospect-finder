import { createClient } from '@/lib/supabase/server';
import { NextResponse } from 'next/server';
import { sendProspectEmail } from '@/lib/email';

export async function POST(req: Request) {
  try {
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });

    const { data: sub } = await supabase.from('subscriptions')
      .select('*').eq('user_id', user.id).eq('status', 'active').limit(1).single();
    if (!sub) return NextResponse.json({ error: 'Abonnement requis' }, { status: 403 });

    const { messageId } = await req.json();

    // Charger message + prospect
    const { data: message } = await supabase.from('messages')
      .select('*, prospect:prospects(*)').eq('id', messageId).eq('user_id', user.id).single();
    if (!message) return NextResponse.json({ error: 'Message introuvable' }, { status: 404 });

    const prospect = message.prospect as any;

    if (message.channel === 'email') {
      if (!prospect?.email) return NextResponse.json({ error: 'Pas d\'email pour ce prospect' }, { status: 400 });

      await sendProspectEmail({
        toEmail: prospect.email,
        toName: prospect.full_name,
        subject: message.subject || 'Prise de contact',
        body: message.body,
      });
    } else if (message.channel === 'linkedin') {
      // LinkedIn API — nécessite accès LinkedIn API
      // Pour l'instant, simuler l'envoi
      if (sub.plan !== 'premium') {
        return NextResponse.json({ error: 'LinkedIn disponible en plan Premium uniquement' }, { status: 403 });
      }
      // TODO: Intégrer LinkedIn API avec LINKEDIN_ACCESS_TOKEN
      // await sendLinkedInMessage(prospect.linkedin_url, message.body);
    }

    // Marquer comme envoyé
    await supabase.from('messages').update({
      status: 'envoye',
      sent_at: new Date().toISOString(),
    }).eq('id', messageId);

    // Mettre à jour statut prospect
    await supabase.from('prospects').update({ status: 'contacte' }).eq('id', prospect.id);

    return NextResponse.json({ success: true });
  } catch (err: any) {
    console.error('Erreur envoi message:', err);
    // Marquer erreur si messageId fourni
    try {
      const supabase = createClient();
      const { messageId } = await req.json().catch(() => ({}));
      if (messageId) {
        await supabase.from('messages').update({
          status: 'erreur',
          error_message: err.message,
        }).eq('id', messageId);
      }
    } catch {}
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
