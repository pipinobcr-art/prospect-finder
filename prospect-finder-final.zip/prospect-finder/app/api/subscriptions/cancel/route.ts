import { createClient } from '@/lib/supabase/server';
import { NextResponse } from 'next/server';
import { revokeMandate } from '@/lib/mollie';
import { addMonths } from 'date-fns';

export async function POST() {
  try {
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });

    const { data: sub } = await supabase.from('subscriptions')
      .select('*').eq('user_id', user.id).eq('status', 'active').limit(1).single();
    if (!sub) return NextResponse.json({ error: 'Aucun abonnement actif' }, { status: 404 });

    // Révoquer mandat Mollie si présent
    if (sub.mollie_customer_id && sub.mollie_mandate_id) {
      await revokeMandate(sub.mollie_customer_id, sub.mollie_mandate_id).catch(console.error);
    }

    // Marquer comme annulé (accès conservé jusqu'à la fin de période)
    const endsAt = sub.current_period_end || new Date().toISOString();
    await supabase.from('subscriptions').update({
      status: 'canceled',
      canceled_at: new Date().toISOString(),
    }).eq('id', sub.id);

    return NextResponse.json({ success: true, endsAt });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
