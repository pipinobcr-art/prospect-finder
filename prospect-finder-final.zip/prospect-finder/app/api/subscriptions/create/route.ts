import { createClient } from '@/lib/supabase/server';
import { NextResponse } from 'next/server';
import { createMollieCustomer, createFirstPayment, PLAN_PRICES } from '@/lib/mollie';

export async function POST(req: Request) {
  try {
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });

    const { plan } = await req.json();
    if (!['standard', 'premium'].includes(plan)) {
      return NextResponse.json({ error: 'Plan invalide' }, { status: 400 });
    }

    // Récupérer profil utilisateur
    const { data: profile } = await supabase.from('profiles').select('*').eq('id', user.id).single();
    const name = profile?.full_name || user.email?.split('@')[0] || 'Client';

    // Vérifier abonnement existant
    const { data: existingSub } = await supabase.from('subscriptions')
      .select('*').eq('user_id', user.id).eq('status', 'active').limit(1).single();

    let mollieCustomerId = existingSub?.mollie_customer_id;

    // Créer client Mollie si besoin
    if (!mollieCustomerId) {
      const customer = await createMollieCustomer(user.email!, name);
      mollieCustomerId = customer.id;
    }

    // Créer paiement initial Mollie
    const planConfig = PLAN_PRICES[plan];
    const payment = await createFirstPayment({
      customerId: mollieCustomerId,
      amount: planConfig.amount,
      description: planConfig.label,
      plan,
      userId: user.id,
    });

    // Créer ou mettre à jour abonnement en BDD (statut pending)
    if (existingSub) {
      await supabase.from('subscriptions').update({
        plan,
        status: 'pending',
        mollie_customer_id: mollieCustomerId,
        mollie_payment_id: payment.id,
      }).eq('id', existingSub.id);
    } else {
      await supabase.from('subscriptions').insert({
        user_id: user.id,
        plan,
        status: 'pending',
        mollie_customer_id: mollieCustomerId,
        mollie_payment_id: payment.id,
      });
    }

    return NextResponse.json({
      checkoutUrl: payment._links.checkout.href,
      paymentId: payment.id,
    });
  } catch (err: any) {
    console.error('Erreur création abonnement:', err);
    return NextResponse.json({ error: err.message || 'Erreur Mollie' }, { status: 500 });
  }
}
