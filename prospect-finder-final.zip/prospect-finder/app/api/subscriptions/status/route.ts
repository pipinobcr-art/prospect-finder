import { createClient } from '@/lib/supabase/server';
import { NextResponse } from 'next/server';

export async function GET() {
  try {
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });

    const { data: sub } = await supabase.from('subscriptions')
      .select('*').eq('user_id', user.id)
      .order('created_at', { ascending: false }).limit(1).single();

    return NextResponse.json({ subscription: sub || null });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
