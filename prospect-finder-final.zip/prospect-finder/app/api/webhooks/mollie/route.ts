import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/server';
import { getPayment, getMandates, createRecurringPayment, PLAN_PRICES } from '@/lib/mollie';
import { addMonths } from 'date-fns';

export async function POST(req: Request) {
  try {
    const body = await req.formData();
    const paymentId = body.get('id') as string;

    if (!paymentId) {
      return NextResponse.json({ error: 'Pas de paymentId' }, { status: 400 });
    }

    // Récupérer paiement Mollie
    const payment = await getPayment(paymentId);
    const { userId, plan } = payment.metadata || {};

    if (!userId || !plan) {
      console.warn('Webhook Mollie: metadata manquante', payment);
      return NextResponse.json({ ok: true });
    }

    const supabase = createAdminClient();

    console.log(`Webhook Mollie: paiement ${paymentId} — statut: ${payment.status} — user: ${userId}`);

    if (payment.status === 'paid') {
      // ─── Paiement réussi ───────────────────────────────────
      const now = new Date();
      const periodEnd = addMonths(now, 1);

      // Récupérer mandats pour le renouvellement automatique
      let mandateId: string | null = null;
      if (payment.customerId) {
        const mandatesData = await getMandates(payment.customerId).catch(() => null);
        const validMandates = mandatesData?._embedded?.mandates?.filter((m: any) => m.status === 'valid') || [];
        mandateId = validMandates[0]?.id || null;
      }

      // Mettre à jour abonnement
      const { data: existingSub } = await supabase.from('subscriptions')
        .select('*').eq('user_id', userId).order('created_at', { ascending: false }).limit(1).single();

      if (existingSub) {
        await supabase.from('subscriptions').update({
          plan,
          status: 'active',
          mollie_payment_id: paymentId,
          mollie_mandate_id: mandateId,
          current_period_start: now.toISOString(),
          current_period_end: periodEnd.toISOString(),
        }).eq('id', existingSub.id);
      } else {
        await supabase.from('subscriptions').insert({
          user_id: userId,
          plan,
          status: 'active',
          mollie_customer_id: payment.customerId,
          mollie_payment_id: paymentId,
          mollie_mandate_id: mandateId,
          current_period_start: now.toISOString(),
          current_period_end: periodEnd.toISOString(),
        });
      }

      console.log(`✅ Abonnement ${plan} activé pour user ${userId}`);

    } else if (payment.status === 'failed' || payment.status === 'canceled' || payment.status === 'expired') {
      // ─── Paiement échoué ───────────────────────────────────
      await supabase.from('subscriptions').update({
        status: payment.status === 'canceled' ? 'canceled' : 'past_due',
      }).eq('user_id', userId).eq('mollie_payment_id', paymentId);

      console.log(`❌ Paiement ${payment.status} pour user ${userId}`);
    }

    return NextResponse.json({ ok: true });
  } catch (err: any) {
    console.error('Erreur webhook Mollie:', err);
    // Toujours retourner 200 pour que Mollie ne réessaie pas
    return NextResponse.json({ ok: true });
  }
}

// Mollie envoie des requêtes POST, pas GET
export async function GET() {
  return NextResponse.json({ ok: true, message: 'Webhook Mollie actif' });
}
