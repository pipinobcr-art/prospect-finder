'use client';
import { useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { Target, Loader2, Eye, EyeOff, Check } from 'lucide-react';

export default function SignupPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const plan = searchParams.get('plan') || 'standard';
  const supabase = createClient();

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  async function handleSignup(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');

    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { full_name: fullName } },
    });

    if (error) { setError(error.message); setLoading(false); }
    else {
      setSuccess(true);
      setTimeout(() => router.push(`/billing?plan=${plan}&new=1`), 2000);
    }
  }

  if (success) return (
    <div className="min-h-screen bg-dark-900 flex items-center justify-center">
      <div className="text-center animate-fade-up">
        <div className="w-16 h-16 bg-brand-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
          <Check className="w-8 h-8 text-brand-400" />
        </div>
        <h2 className="text-2xl font-bold text-white mb-2">Compte créé !</h2>
        <p className="text-gray-400">Redirection vers le paiement…</p>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-dark-900 flex items-center justify-center px-4">
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-brand-500/5 rounded-full blur-3xl" />
      </div>

      <div className="w-full max-w-md animate-fade-up">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2 mb-6">
            <div className="w-10 h-10 bg-brand-500 rounded-xl flex items-center justify-center">
              <Target className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold text-white">Prospect Finder</span>
          </Link>
          <h1 className="text-2xl font-bold text-white">Créer votre compte</h1>
          <p className="text-gray-400 mt-2">
            Plan sélectionné :{' '}
            <span className="text-brand-400 font-semibold capitalize">{plan}</span>
            {plan === 'standard' ? ' — 29€/mois' : ' — 79€/mois'}
          </p>
        </div>

        <div className="card p-8">
          <form onSubmit={handleSignup} className="space-y-5">
            {error && (
              <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-3 text-red-400 text-sm">
                {error}
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Nom complet</label>
              <input type="text" value={fullName} onChange={e => setFullName(e.target.value)}
                className="input-dark" placeholder="Jean Dupont" required />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Email professionnel</label>
              <input type="email" value={email} onChange={e => setEmail(e.target.value)}
                className="input-dark" placeholder="jean@entreprise.com" required />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Mot de passe</label>
              <div className="relative">
                <input type={showPass ? 'text' : 'password'} value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="input-dark pr-12" placeholder="8 caractères minimum" minLength={8} required />
                <button type="button" onClick={() => setShowPass(!showPass)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white">
                  {showPass ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <button type="submit" disabled={loading} className="btn-primary w-full flex items-center justify-center gap-2">
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Créer mon compte →'}
            </button>

            <p className="text-xs text-gray-500 text-center">
              En créant un compte, vous acceptez nos <a href="#" className="text-brand-400">CGU</a> et{' '}
              <a href="#" className="text-brand-400">Politique de confidentialité</a>
            </p>
          </form>

          <p className="text-center text-sm text-gray-500 mt-6">
            Déjà un compte ?{' '}
            <Link href="/auth/login" className="text-brand-400 hover:text-brand-300 font-medium">Se connecter</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
