import { createClient } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';
import Sidebar from '@/components/layout/Sidebar';
import TopBar from '@/components/layout/TopBar';

export default async function BillingLayout({ children }: { children: React.ReactNode }) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/auth/login');
  const { data: profile } = await supabase.from('profiles').select('*').eq('id', user.id).single();
  const { data: subscription } = await supabase.from('subscriptions').select('*')
    .eq('user_id', user.id).order('created_at', { ascending: false }).limit(1).single();
  return (
    <div className="min-h-screen bg-dark-900 flex">
      <Sidebar user={user} subscription={subscription} />
      <div className="flex-1 flex flex-col min-h-screen ml-64">
        <TopBar user={user} profile={profile} />
        <main className="flex-1 p-6 md:p-8">{children}</main>
      </div>
    </div>
  );
}
