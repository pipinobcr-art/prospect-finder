'use client';
import { useState, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { CreditCard, Check, Crown, Zap, AlertCircle, Loader2, ExternalLink, Calendar, RefreshCw } from 'lucide-react';
import { formatDate, formatCurrency, STATUS_COLORS, STATUS_LABELS } from '@/lib/utils';
import { PLANS } from '@/types';
import type { Subscription } from '@/types';

function BillingContent() {
  const supabase = createClient();
  const searchParams = useSearchParams();
  const planParam = searchParams.get('plan') || 'standard';
  const isNew = searchParams.get('new') === '1';

  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [loading, setLoading] = useState(true);
  const [subscribing, setSubscribing] = useState<string | null>(null);
  const [canceling, setCanceling] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => { loadSubscription(); }, []);

  async function loadSubscription() {
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const { data } = await supabase.from('subscriptions').select('*')
      .eq('user_id', user.id).order('created_at', { ascending: false }).limit(1).single();
    setSubscription(data);
    setLoading(false);
  }

  async function handleSubscribe(plan: string) {
    setSubscribing(plan);
    setError('');
    try {
      const res = await fetch('/api/subscriptions/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ plan }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error);
      // Rediriger vers Mollie
      window.location.href = json.checkoutUrl;
    } catch (err: any) {
      setError(err.message);
      setSubscribing(null);
    }
  }

  async function handleCancel() {
    if (!confirm('Êtes-vous sûr de vouloir annuler votre abonnement ? Vous conserverez l\'accès jusqu\'à la fin de la période en cours.')) return;
    setCanceling(true);
    try {
      const res = await fetch('/api/subscriptions/cancel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error);
      setSuccess('Abonnement annulé. Vous conservez l\'accès jusqu\'au ' + formatDate(json.endsAt));
      await loadSubscription();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setCanceling(false);
    }
  }

  const isActive   = subscription?.status === 'active';
  const isPremium  = subscription?.plan === 'premium' && isActive;
  const isStandard = subscription?.plan === 'standard' && isActive;

  return (
    <div className="space-y-8 animate-fade-up max-w-4xl">
      <div>
        <h1 className="text-2xl font-bold text-white">Abonnement</h1>
        <p className="text-gray-400 mt-1">Gérez votre plan et vos paiements</p>
      </div>

      {error && (
        <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4 flex items-center gap-3 text-red-400">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <p className="text-sm">{error}</p>
        </div>
      )}

      {success && (
        <div className="bg-brand-500/10 border border-brand-500/30 rounded-xl p-4 flex items-center gap-3 text-brand-400">
          <Check className="w-5 h-5 flex-shrink-0" />
          <p className="text-sm">{success}</p>
        </div>
      )}

      {/* Abonnement actuel */}
      {!loading && subscription && (
        <div className="card p-6">
          <h2 className="text-lg font-semibold text-white mb-5 flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-brand-400" />
            Abonnement actuel
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div>
              <p className="text-xs text-gray-500 uppercase tracking-wide mb-1">Plan</p>
              <div className="flex items-center gap-2">
                {isPremium ? <Crown className="w-4 h-4 text-yellow-400" /> : <Zap className="w-4 h-4 text-brand-400" />}
                <span className="font-semibold text-white capitalize">{subscription.plan}</span>
              </div>
            </div>
            <div>
              <p className="text-xs text-gray-500 uppercase tracking-wide mb-1">Statut</p>
              <span className={`badge ${STATUS_COLORS[subscription.status]}`}>
                {STATUS_LABELS[subscription.status]}
              </span>
            </div>
            <div>
              <p className="text-xs text-gray-500 uppercase tracking-wide mb-1">Renouvellement</p>
              <p className="text-sm text-white flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-gray-400" />
                {subscription.current_period_end ? formatDate(subscription.current_period_end) : '—'}
              </p>
            </div>
            <div>
              <p className="text-xs text-gray-500 uppercase tracking-wide mb-1">Montant</p>
              <p className="text-sm font-semibold text-white">
                {formatCurrency(PLANS[subscription.plan].price)}/mois
              </p>
            </div>
          </div>

          {isActive && (
            <div className="mt-6 pt-5 border-t border-dark-400 flex gap-3">
              {isStandard && (
                <button onClick={() => handleSubscribe('premium')} disabled={!!subscribing}
                  className="btn-primary flex items-center gap-2 text-sm">
                  {subscribing === 'premium' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Crown className="w-4 h-4" />}
                  Passer Premium
                </button>
              )}
              <button onClick={handleCancel} disabled={canceling}
                className="text-sm text-red-400 hover:text-red-300 hover:bg-red-500/10 px-4 py-2 rounded-xl transition-all flex items-center gap-2">
                {canceling ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
                Annuler l'abonnement
              </button>
            </div>
          )}
        </div>
      )}

      {/* Plans */}
      <div>
        <h2 className="text-lg font-semibold text-white mb-5">
          {isActive ? 'Changer de plan' : 'Choisir un plan'}
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Standard */}
          <div className={`card p-7 relative ${isStandard ? 'border-brand-500/50' : ''}`}>
            {isStandard && (
              <div className="absolute -top-3 left-6 bg-brand-500 text-white text-xs font-bold px-3 py-1 rounded-full">
                PLAN ACTUEL
              </div>
            )}
            <div className="flex items-center gap-2 mb-1">
              <Zap className="w-5 h-5 text-brand-400" />
              <span className="font-bold text-white text-lg">Standard</span>
            </div>
            <div className="flex items-end gap-1 mb-1">
              <span className="text-4xl font-bold text-white">29€</span>
              <span className="text-gray-400 mb-1">/mois</span>
            </div>
            <p className="text-gray-500 text-sm mb-6">Pour indépendants et petites équipes</p>
            <ul className="space-y-2.5 mb-7">
              {STANDARD_FEATURES.map(f => (
                <li key={f} className="flex items-center gap-2.5 text-sm text-gray-300">
                  <Check className="w-4 h-4 text-brand-400 flex-shrink-0" />{f}
                </li>
              ))}
            </ul>
            <button onClick={() => handleSubscribe('standard')}
              disabled={!!subscribing || isStandard}
              className={`w-full ${isStandard ? 'btn-secondary opacity-50 cursor-not-allowed' : 'btn-secondary'} flex items-center justify-center gap-2`}>
              {subscribing === 'standard' ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
              {isStandard ? 'Plan actuel' : 'Choisir Standard'}
            </button>
          </div>

          {/* Premium */}
          <div className={`card p-7 relative ${isPremium ? 'border-yellow-500/50' : 'border-brand-500/20'}`}
            style={!isPremium ? { boxShadow: '0 0 30px rgba(20,184,151,0.1)' } : {}}>
            {isPremium ? (
              <div className="absolute -top-3 left-6 bg-yellow-500 text-dark-900 text-xs font-bold px-3 py-1 rounded-full">
                PLAN ACTUEL
              </div>
            ) : (
              <div className="absolute -top-3 left-6 bg-brand-500 text-white text-xs font-bold px-3 py-1 rounded-full">
                RECOMMANDÉ
              </div>
            )}
            <div className="flex items-center gap-2 mb-1">
              <Crown className="w-5 h-5 text-yellow-400" />
              <span className="font-bold text-white text-lg">Premium</span>
            </div>
            <div className="flex items-end gap-1 mb-1">
              <span className="text-4xl font-bold text-white">79€</span>
              <span className="text-gray-400 mb-1">/mois</span>
            </div>
            <p className="text-gray-500 text-sm mb-6">Pour équipes commerciales et agences</p>
            <ul className="space-y-2.5 mb-7">
              {PREMIUM_FEATURES.map(f => (
                <li key={f} className="flex items-center gap-2.5 text-sm text-gray-300">
                  <Check className="w-4 h-4 text-yellow-400 flex-shrink-0" />{f}
                </li>
              ))}
            </ul>
            <button onClick={() => handleSubscribe('premium')}
              disabled={!!subscribing || isPremium}
              className={`w-full ${isPremium ? 'btn-secondary opacity-50 cursor-not-allowed' : 'btn-primary'} flex items-center justify-center gap-2`}>
              {subscribing === 'premium' ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
              {isPremium ? 'Plan actuel' : 'Choisir Premium'}
            </button>
          </div>
        </div>
      </div>

      <div className="card p-5 flex items-start gap-3">
        <RefreshCw className="w-5 h-5 text-brand-400 flex-shrink-0 mt-0.5" />
        <div>
          <p className="text-sm font-medium text-white">Renouvellement automatique</p>
          <p className="text-xs text-gray-400 mt-1">
            Votre abonnement se renouvelle automatiquement chaque mois via Mollie.
            Les paiements sont sécurisés et chiffrés. Résiliez à tout moment depuis cette page.
          </p>
        </div>
      </div>
    </div>
  );
}

export default function BillingPage() {
  return (
    <Suspense fallback={<div className="p-12 text-center"><Loader2 className="w-8 h-8 animate-spin text-brand-400 mx-auto" /></div>}>
      <BillingContent />
    </Suspense>
  );
}

const STANDARD_FEATURES = [
  '100 prospects/mois', '50 messages/mois',
  'Recherche IA par secteur', 'Génération messages IA', 'Envoi email',
  'Tableau de bord', 'Support email',
];
const PREMIUM_FEATURES = [
  '1 000 prospects/mois', '500 messages/mois',
  'Recherche IA avancée', 'Messages ultra-personnalisés',
  'Envoi email + LinkedIn', 'Envoi automatique planifié',
  'Analytics avancés', 'Support prioritaire 24h',
];
