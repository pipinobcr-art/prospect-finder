import Link from 'next/link';
import { Check, ArrowRight } from 'lucide-react';

export default function BillingSuccessPage({
  searchParams,
}: {
  searchParams: { plan?: string };
}) {
  const plan = searchParams.plan || 'standard';
  return (
    <div className="min-h-screen bg-dark-900 flex items-center justify-center px-4">
      <div className="text-center max-w-md animate-fade-up">
        <div className="w-20 h-20 bg-brand-500/20 rounded-full flex items-center justify-center mx-auto mb-6 border border-brand-500/30">
          <Check className="w-10 h-10 text-brand-400" />
        </div>
        <h1 className="text-3xl font-bold text-white mb-3">Paiement confirmé !</h1>
        <p className="text-gray-400 mb-2">
          Votre abonnement <span className="text-brand-400 font-semibold capitalize">{plan}</span> est maintenant actif.
        </p>
        <p className="text-gray-500 text-sm mb-8">
          Vous allez recevoir un email de confirmation. Le renouvellement est automatique chaque mois via Mollie.
        </p>
        <Link href="/dashboard" className="btn-primary inline-flex items-center gap-2">
          Accéder au tableau de bord
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );
}
