import { createClient } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';
import Link from 'next/link';
import { formatDate, formatRelative, STATUS_LABELS, STATUS_COLORS, cn } from '@/lib/utils';
import { Users, MessageSquare, TrendingUp, Zap, ArrowRight, Plus, Target } from 'lucide-react';

export default async function DashboardPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/auth/login');

  const [
    { count: totalProspects },
    { count: totalMessages },
    { count: converted },
    { data: recentProspects },
    { data: subscription },
  ] = await Promise.all([
    supabase.from('prospects').select('*', { count: 'exact', head: true }).eq('user_id', user.id),
    supabase.from('messages').select('*', { count: 'exact', head: true }).eq('user_id', user.id),
    supabase.from('prospects').select('*', { count: 'exact', head: true }).eq('user_id', user.id).eq('status', 'converti'),
    supabase.from('prospects').select('*').eq('user_id', user.id).order('created_at', { ascending: false }).limit(5),
    supabase.from('subscriptions').select('*').eq('user_id', user.id).eq('status', 'active').limit(1).single(),
  ]);

  const conversionRate = totalProspects ? Math.round(((converted || 0) / totalProspects) * 100) : 0;
  const profile = await supabase.from('profiles').select('full_name').eq('id', user.id).single();
  const firstName = profile.data?.full_name?.split(' ')[0] || 'là';

  const hasActiveSub = !!subscription;

  return (
    <div className="space-y-8 animate-fade-up">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Bonjour, {firstName} 👋</h1>
          <p className="text-gray-400 mt-1">Voici un aperçu de votre activité</p>
        </div>
        <Link href="/prospects?new=1" className="btn-primary flex items-center gap-2">
          <Plus className="w-4 h-4" />
          Nouvelle campagne
        </Link>
      </div>

      {/* Abonnement inactif */}
      {!hasActiveSub && (
        <div className="card p-6 border-yellow-500/30 bg-yellow-500/5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-yellow-500/10 rounded-xl flex items-center justify-center">
                <Zap className="w-5 h-5 text-yellow-400" />
              </div>
              <div>
                <p className="font-semibold text-white">Aucun abonnement actif</p>
                <p className="text-sm text-gray-400">Activez un plan pour commencer la prospection IA</p>
              </div>
            </div>
            <Link href="/billing" className="btn-primary text-sm py-2 px-5">
              Activer maintenant
            </Link>
          </div>
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {[
          { label: 'Total Prospects', value: totalProspects || 0, icon: Users,          color: 'text-blue-400',   bg: 'bg-blue-500/10' },
          { label: 'Messages envoyés', value: totalMessages || 0, icon: MessageSquare,  color: 'text-brand-400',  bg: 'bg-brand-500/10' },
          { label: 'Convertis',        value: converted || 0,     icon: Target,          color: 'text-green-400',  bg: 'bg-green-500/10' },
          { label: 'Taux conversion',  value: `${conversionRate}%`, icon: TrendingUp,   color: 'text-purple-400', bg: 'bg-purple-500/10' },
        ].map((kpi) => (
          <div key={kpi.label} className="card p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm text-gray-400">{kpi.label}</span>
              <div className={`w-9 h-9 ${kpi.bg} rounded-xl flex items-center justify-center`}>
                <kpi.icon className={`w-5 h-5 ${kpi.color}`} />
              </div>
            </div>
            <div className="text-3xl font-bold text-white">{kpi.value}</div>
          </div>
        ))}
      </div>

      {/* Prospects récents */}
      <div className="card">
        <div className="flex items-center justify-between p-6 border-b border-dark-400">
          <h2 className="text-lg font-semibold text-white">Prospects récents</h2>
          <Link href="/prospects" className="text-sm text-brand-400 hover:text-brand-300 flex items-center gap-1">
            Voir tout <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        {!recentProspects?.length ? (
          <div className="p-12 text-center">
            <Users className="w-12 h-12 text-gray-600 mx-auto mb-3" />
            <p className="text-gray-400 font-medium">Aucun prospect pour l'instant</p>
            <p className="text-gray-500 text-sm mt-1">Lancez votre première recherche IA</p>
            <Link href="/prospects?new=1" className="btn-primary inline-flex items-center gap-2 mt-4 text-sm">
              <Plus className="w-4 h-4" /> Lancer une recherche
            </Link>
          </div>
        ) : (
          <div className="divide-y divide-dark-400">
            {recentProspects.map((p) => (
              <div key={p.id} className="flex items-center justify-between px-6 py-4 hover:bg-dark-700/50 transition-colors">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-dark-600 rounded-full flex items-center justify-center text-white font-semibold text-sm">
                    {p.full_name.split(' ').map((n: string) => n[0]).join('').toUpperCase().slice(0, 2)}
                  </div>
                  <div>
                    <p className="font-medium text-white text-sm">{p.full_name}</p>
                    <p className="text-xs text-gray-500">{p.company} · {p.job_title}</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <span className={`badge ${STATUS_COLORS[p.status]}`}>{STATUS_LABELS[p.status]}</span>
                  <span className="text-xs text-gray-500 hidden sm:block">{formatRelative(p.created_at)}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
