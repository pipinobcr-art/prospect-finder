'use client';
import { useState, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { MessageSquare, Bot, Loader2, Send, Mail, Linkedin, RefreshCw, Check, X, ChevronDown } from 'lucide-react';
import { STATUS_COLORS, STATUS_LABELS, formatRelative } from '@/lib/utils';
import type { Message, Prospect } from '@/types';

function MessagesContent() {
  const supabase = createClient();
  const searchParams = useSearchParams();
  const prospectParam = searchParams.get('prospect');

  const [messages, setMessages] = useState<Message[]>([]);
  const [prospects, setProspects] = useState<Prospect[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [sending, setSending] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState('');

  const [form, setForm] = useState({
    prospectId: prospectParam || '',
    channel: 'email' as 'email' | 'linkedin',
    objective: '',
  });

  const [preview, setPreview] = useState<{ subject?: string; body: string } | null>(null);

  useEffect(() => {
    loadData();
    if (prospectParam) setShowForm(true);
  }, []);

  async function loadData() {
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const [{ data: msgs }, { data: prsp }] = await Promise.all([
      supabase.from('messages').select('*, prospect:prospects(full_name, company, email)')
        .eq('user_id', user.id).order('created_at', { ascending: false }),
      supabase.from('prospects').select('id, full_name, company, email, linkedin_url, job_title, industry, ai_summary')
        .eq('user_id', user.id).order('full_name'),
    ]);

    setMessages(msgs || []);
    setProspects(prsp || []);
    setLoading(false);
  }

  async function handleGenerate(e: React.FormEvent) {
    e.preventDefault();
    setGenerating(true);
    setError('');
    setPreview(null);

    try {
      const res = await fetch('/api/prospects/generate-message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, save: false }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error);
      setPreview(json.message);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setGenerating(false);
    }
  }

  async function handleSaveAndSend(autoSend = false) {
    if (!preview) return;
    setSending('generating');
    try {
      // Sauvegarder
      const res = await fetch('/api/prospects/generate-message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, save: true }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error);

      if (autoSend && json.saved) {
        // Envoyer
        const sendRes = await fetch('/api/prospects/send', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ messageId: json.saved.id }),
        });
        const sendJson = await sendRes.json();
        if (!sendRes.ok) throw new Error(sendJson.error);
      }

      setShowForm(false);
      setPreview(null);
      await loadData();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSending(null);
    }
  }

  async function sendMessage(messageId: string) {
    setSending(messageId);
    try {
      const res = await fetch('/api/prospects/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messageId }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error);
      await loadData();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setSending(null);
    }
  }

  return (
    <div className="space-y-6 animate-fade-up">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Messages</h1>
          <p className="text-gray-400 mt-1">{messages.length} message{messages.length !== 1 ? 's' : ''}</p>
        </div>
        <button onClick={() => setShowForm(!showForm)} className="btn-primary flex items-center gap-2">
          <Bot className="w-4 h-4" /> Générer un message IA
        </button>
      </div>

      {/* Formulaire génération */}
      {showForm && (
        <div className="card p-6 border-brand-500/30 bg-brand-500/5 animate-fade-up space-y-5">
          <div className="flex items-center gap-2">
            <Bot className="w-5 h-5 text-brand-400" />
            <h2 className="text-lg font-semibold text-white">Générer un message IA</h2>
          </div>

          {error && <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-3 text-red-400 text-sm">{error}</div>}

          <form onSubmit={handleGenerate} className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-1">
              <label className="block text-sm text-gray-300 mb-1.5">Prospect</label>
              <select value={form.prospectId} onChange={e => setForm({...form, prospectId: e.target.value})}
                className="input-dark" required>
                <option value="">Sélectionner…</option>
                {prospects.map(p => (
                  <option key={p.id} value={p.id}>{p.full_name} — {p.company}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm text-gray-300 mb-1.5">Canal</label>
              <select value={form.channel} onChange={e => setForm({...form, channel: e.target.value as any})}
                className="input-dark">
                <option value="email">Email</option>
                <option value="linkedin">LinkedIn</option>
              </select>
            </div>
            <div>
              <label className="block text-sm text-gray-300 mb-1.5">Objectif (optionnel)</label>
              <input value={form.objective} onChange={e => setForm({...form, objective: e.target.value})}
                className="input-dark" placeholder="Proposer une démo…" />
            </div>
            <div className="md:col-span-3 flex gap-3">
              <button type="submit" disabled={generating || !form.prospectId}
                className="btn-primary flex items-center gap-2">
                {generating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Bot className="w-4 h-4" />}
                {generating ? 'Génération…' : 'Générer'}
              </button>
              <button type="button" onClick={() => { setShowForm(false); setPreview(null); }} className="btn-secondary">Annuler</button>
            </div>
          </form>

          {/* Prévisualisation */}
          {preview && (
            <div className="border-t border-dark-400 pt-5 space-y-4 animate-fade-up">
              <h3 className="text-sm font-medium text-gray-300">Aperçu du message généré</h3>
              {preview.subject && (
                <div>
                  <label className="block text-xs text-gray-500 mb-1">Objet</label>
                  <input value={preview.subject} onChange={e => setPreview({...preview, subject: e.target.value})}
                    className="input-dark text-sm" />
                </div>
              )}
              <div>
                <label className="block text-xs text-gray-500 mb-1">Message</label>
                <textarea value={preview.body} onChange={e => setPreview({...preview, body: e.target.value})}
                  className="input-dark text-sm min-h-40 resize-y" />
              </div>
              <div className="flex gap-3">
                <button onClick={() => handleSaveAndSend(false)} disabled={!!sending}
                  className="btn-secondary flex items-center gap-2 text-sm">
                  {sending === 'generating' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                  Sauvegarder
                </button>
                <button onClick={() => handleSaveAndSend(true)} disabled={!!sending}
                  className="btn-primary flex items-center gap-2 text-sm">
                  {sending === 'generating' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                  Sauvegarder & Envoyer
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Liste messages */}
      <div className="card overflow-hidden">
        {loading ? (
          <div className="p-12 text-center"><Loader2 className="w-8 h-8 animate-spin text-brand-400 mx-auto" /></div>
        ) : !messages.length ? (
          <div className="p-12 text-center">
            <MessageSquare className="w-12 h-12 text-gray-600 mx-auto mb-3" />
            <p className="text-gray-400 font-medium">Aucun message</p>
            <button onClick={() => setShowForm(true)} className="btn-primary inline-flex items-center gap-2 mt-4 text-sm">
              <Bot className="w-4 h-4" /> Générer un premier message
            </button>
          </div>
        ) : (
          <div className="divide-y divide-dark-400/50">
            {messages.map((m) => (
              <div key={m.id} className="flex items-center gap-4 px-6 py-4 hover:bg-dark-700/30 transition-colors">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${m.channel === 'email' ? 'bg-blue-500/10' : 'bg-blue-600/10'}`}>
                  {m.channel === 'email'
                    ? <Mail className="w-4 h-4 text-blue-400" />
                    : <Linkedin className="w-4 h-4 text-blue-500" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-white text-sm truncate">
                    {(m.prospect as any)?.full_name} — {(m.prospect as any)?.company}
                  </p>
                  {m.subject && <p className="text-xs text-gray-400 truncate mt-0.5">{m.subject}</p>}
                  <p className="text-xs text-gray-500 truncate mt-0.5">{m.body.substring(0, 80)}…</p>
                </div>
                <div className="flex items-center gap-3 flex-shrink-0">
                  <span className={`badge ${STATUS_COLORS[m.status]}`}>{STATUS_LABELS[m.status]}</span>
                  {m.status === 'brouillon' && (
                    <button onClick={() => sendMessage(m.id)} disabled={sending === m.id}
                      className="btn-primary text-xs py-1.5 px-3 flex items-center gap-1">
                      {sending === m.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <Send className="w-3 h-3" />}
                      Envoyer
                    </button>
                  )}
                  {m.sent_at && <span className="text-xs text-gray-500">{formatRelative(m.sent_at)}</span>}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default function MessagesPage() {
  return (
    <Suspense fallback={<div className="p-12 text-center"><Loader2 className="w-8 h-8 animate-spin text-brand-400 mx-auto" /></div>}>
      <MessagesContent />
    </Suspense>
  );
}
