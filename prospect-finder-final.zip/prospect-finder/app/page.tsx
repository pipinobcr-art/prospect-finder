import Link from 'next/link';
import {
  Zap, Users, MessageSquare, TrendingUp, Shield, Globe,
  ArrowRight, Check, Star, Bot, Send, Target
} from 'lucide-react';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-dark-900">
      {/* ─── NAV ─────────────────────────────────── */}
      <nav className="fixed top-0 w-full z-50 border-b border-dark-400/50 bg-dark-900/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-brand-500 rounded-lg flex items-center justify-center">
              <Target className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-white text-lg">Prospect Finder</span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm text-gray-400">
            <a href="#fonctionnalites" className="hover:text-white transition-colors">Fonctionnalités</a>
            <a href="#tarifs" className="hover:text-white transition-colors">Tarifs</a>
            <a href="#faq" className="hover:text-white transition-colors">FAQ</a>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/auth/login" className="text-sm text-gray-400 hover:text-white transition-colors px-4 py-2">
              Connexion
            </Link>
            <Link href="/auth/signup" className="btn-primary text-sm py-2 px-5">
              Essai gratuit
            </Link>
          </div>
        </div>
      </nav>

      {/* ─── HERO ────────────────────────────────── */}
      <section className="pt-32 pb-20 px-6 relative overflow-hidden">
        {/* Background glow */}
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-brand-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-4xl mx-auto text-center relative">
          <div className="inline-flex items-center gap-2 bg-brand-500/10 border border-brand-500/20 rounded-full px-4 py-2 text-brand-400 text-sm mb-8">
            <Bot className="w-4 h-4" />
            <span>Propulsé par l'IA Claude d'Anthropic</span>
          </div>

          <h1 className="text-5xl md:text-7xl font-bold text-white leading-tight mb-6">
            Trouvez vos{' '}
            <span className="gradient-text">clients idéaux</span>
            {' '}automatiquement
          </h1>

          <p className="text-xl text-gray-400 max-w-2xl mx-auto mb-10 leading-relaxed">
            Prospect Finder utilise l'IA pour identifier, contacter et convertir
            vos prospects B2B — par email ou LinkedIn — en pilote automatique.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/auth/signup" className="btn-primary text-base py-4 px-8 flex items-center justify-center gap-2">
              Commencer gratuitement
              <ArrowRight className="w-5 h-5" />
            </Link>
            <a href="#tarifs" className="btn-secondary text-base py-4 px-8">
              Voir les tarifs
            </a>
          </div>

          <p className="mt-6 text-sm text-gray-500">
            ✓ Aucune carte bancaire requise pour l'essai · ✓ 14 jours gratuits
          </p>
        </div>

        {/* Floating stats */}
        <div className="max-w-3xl mx-auto mt-20 grid grid-cols-3 gap-6">
          {[
            { value: '+2 400', label: 'Prospects trouvés/mois', icon: Users },
            { value: '68%', label: 'Taux d\'ouverture moyen', icon: TrendingUp },
            { value: '< 5min', label: 'Pour lancer une campagne', icon: Zap },
          ].map((stat) => (
            <div key={stat.label} className="card p-6 text-center glow-brand-sm">
              <stat.icon className="w-6 h-6 text-brand-400 mx-auto mb-3" />
              <div className="text-2xl font-bold text-white">{stat.value}</div>
              <div className="text-sm text-gray-500 mt-1">{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ─── FONCTIONNALITÉS ─────────────────────── */}
      <section id="fonctionnalites" className="py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">Tout ce dont vous avez besoin</h2>
            <p className="text-gray-400 text-lg">Une plateforme complète pour votre prospection B2B</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {FEATURES.map((f) => (
              <div key={f.title} className="card-hover p-6">
                <div className="w-12 h-12 bg-brand-500/10 rounded-xl flex items-center justify-center mb-4">
                  <f.icon className="w-6 h-6 text-brand-400" />
                </div>
                <h3 className="text-white font-semibold text-lg mb-2">{f.title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── TARIFS ──────────────────────────────── */}
      <section id="tarifs" className="py-24 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">Tarifs simples et transparents</h2>
            <p className="text-gray-400 text-lg">Résiliez à tout moment. Pas de frais cachés.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Standard */}
            <div className="card p-8">
              <div className="text-brand-400 font-semibold text-sm uppercase tracking-wide mb-4">Standard</div>
              <div className="flex items-end gap-1 mb-2">
                <span className="text-5xl font-bold text-white">29€</span>
                <span className="text-gray-400 mb-2">/mois</span>
              </div>
              <p className="text-gray-500 text-sm mb-8">Idéal pour les indépendants et petites équipes</p>
              <ul className="space-y-3 mb-8">
                {STANDARD_FEATURES.map(f => (
                  <li key={f} className="flex items-center gap-3 text-sm text-gray-300">
                    <Check className="w-4 h-4 text-brand-400 flex-shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
              <Link href="/auth/signup?plan=standard" className="btn-secondary w-full text-center block">
                Choisir Standard
              </Link>
            </div>

            {/* Premium */}
            <div className="relative card p-8 border-brand-500/40 glow-brand">
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-brand-500 text-white text-xs font-bold px-4 py-1 rounded-full">
                LE PLUS POPULAIRE
              </div>
              <div className="text-brand-400 font-semibold text-sm uppercase tracking-wide mb-4">Premium</div>
              <div className="flex items-end gap-1 mb-2">
                <span className="text-5xl font-bold text-white">79€</span>
                <span className="text-gray-400 mb-2">/mois</span>
              </div>
              <p className="text-gray-500 text-sm mb-8">Pour les équipes commerciales et agences</p>
              <ul className="space-y-3 mb-8">
                {PREMIUM_FEATURES.map(f => (
                  <li key={f} className="flex items-center gap-3 text-sm text-gray-300">
                    <Check className="w-4 h-4 text-brand-400 flex-shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
              <Link href="/auth/signup?plan=premium" className="btn-primary w-full text-center block">
                Choisir Premium
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ─── FOOTER ──────────────────────────────── */}
      <footer className="border-t border-dark-400 py-12 px-6">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 bg-brand-500 rounded-lg flex items-center justify-center">
              <Target className="w-4 h-4 text-white" />
            </div>
            <span className="font-bold text-white">Prospect Finder</span>
          </div>
          <p className="text-gray-500 text-sm">© 2025 Prospect Finder. Tous droits réservés.</p>
          <div className="flex gap-6 text-sm text-gray-500">
            <a href="#" className="hover:text-white transition-colors">Confidentialité</a>
            <a href="#" className="hover:text-white transition-colors">CGU</a>
            <a href="mailto:support@prospectfinder.io" className="hover:text-white transition-colors">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  );
}

const FEATURES = [
  { icon: Bot,          title: 'Recherche IA automatique',    desc: 'L\'IA analyse votre secteur et pays cible pour trouver des prospects qualifiés en quelques secondes.' },
  { icon: MessageSquare, title: 'Messages ultra-personnalisés', desc: 'Chaque message est généré par l\'IA et adapté au profil unique de chaque prospect.' },
  { icon: Send,         title: 'Envoi automatique',           desc: 'L\'IA envoie les messages par email ou LinkedIn automatiquement selon votre calendrier.' },
  { icon: Globe,        title: 'Multi-pays & secteurs',       desc: 'Ciblez n\'importe quel pays ou secteur : SaaS, immobilier, e-commerce, finance et bien plus.' },
  { icon: TrendingUp,   title: 'Tableau de bord avancé',      desc: 'Suivez vos taux d\'ouverture, réponses et conversions en temps réel depuis votre dashboard.' },
  { icon: Shield,       title: 'Paiements sécurisés Mollie',  desc: 'Abonnement mensuel automatique via Mollie. Résiliez à tout moment, aucun engagement.' },
];

const STANDARD_FEATURES = [
  '100 prospects/mois',
  '50 messages/mois',
  'Recherche IA par secteur',
  'Génération de messages IA',
  'Envoi email',
  'Tableau de bord basique',
  'Support par email',
];

const PREMIUM_FEATURES = [
  '1 000 prospects/mois',
  '500 messages/mois',
  'Recherche IA avancée',
  'Messages IA ultra-personnalisés',
  'Envoi email + LinkedIn',
  'Envoi automatique planifié',
  'Analytics avancés',
  'Support prioritaire',
];
