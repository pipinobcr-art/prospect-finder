'use client';
import { useState, useEffect } from 'react';
import { createClient } from '@/lib/supabase/client';
import { INDUSTRIES, COUNTRIES, PLATFORMS, STATUS_LABELS, STATUS_COLORS, formatRelative } from '@/lib/utils';
import { Search, Plus, Bot, Loader2, Filter, Mail, Linkedin, ChevronDown, ExternalLink, MessageSquare, Trash2, RefreshCw } from 'lucide-react';
import type { Prospect } from '@/types';

type FilterStatus = 'tous' | 'nouveau' | 'contacte' | 'repondu' | 'converti' | 'ignore';

export default function ProspectsPage() {
  const supabase = createClient();
  const [prospects, setProspects] = useState<Prospect[]>([]);
  const [loading, setLoading] = useState(true);
  const [searching, setSearching] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [filterStatus, setFilterStatus] = useState<FilterStatus>('tous');
  const [searchQuery, setSearchQuery] = useState('');
  const [error, setError] = useState('');

  const [form, setForm] = useState({
    industry: INDUSTRIES[0],
    country: COUNTRIES[0],
    platform: 'email',
    keywords: '',
    count: 10,
    campaignName: '',
  });

  useEffect(() => { loadProspects(); }, []);

  async function loadProspects() {
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const { data } = await supabase
      .from('prospects').select('*').eq('user_id', user.id)
      .order('created_at', { ascending: false });
    setProspects(data || []);
    setLoading(false);
  }

  async function handleAISearch(e: React.FormEvent) {
    e.preventDefault();
    setSearching(true);
    setError('');
    try {
      const res = await fetch('/api/prospects/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          industry: form.industry,
          country: form.country,
          platform: form.platform,
          keywords: form.keywords.split(',').map(k => k.trim()).filter(Boolean),
          count: form.count,
          campaignName: form.campaignName || `${form.industry} — ${form.country}`,
        }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Erreur recherche');
      setShowForm(false);
      await loadProspects();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSearching(false);
    }
  }

  async function updateStatus(id: string, status: string) {
    await supabase.from('prospects').update({ status }).eq('id', id);
    setProspects(ps => ps.map(p => p.id === id ? { ...p, status: status as any } : p));
  }

  async function deleteProspect(id: string) {
    if (!confirm('Supprimer ce prospect ?')) return;
    await supabase.from('prospects').delete().eq('id', id);
    setProspects(ps => ps.filter(p => p.id !== id));
  }

  async function generateMessage(prospect: Prospect) {
    window.location.href = `/messages?prospect=${prospect.id}`;
  }

  const filtered = prospects.filter(p => {
    const matchStatus = filterStatus === 'tous' || p.status === filterStatus;
    const q = searchQuery.toLowerCase();
    const matchSearch = !q || p.full_name.toLowerCase().includes(q)
      || p.company?.toLowerCase().includes(q)
      || p.email?.toLowerCase().includes(q);
    return matchStatus && matchSearch;
  });

  return (
    <div className="space-y-6 animate-fade-up">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Prospects</h1>
          <p className="text-gray-400 mt-1">{prospects.length} prospect{prospects.length !== 1 ? 's' : ''} au total</p>
        </div>
        <button onClick={() => setShowForm(!showForm)} className="btn-primary flex items-center gap-2">
          <Bot className="w-4 h-4" />
          Recherche IA
        </button>
      </div>

      {/* Formulaire recherche IA */}
      {showForm && (
        <div className="card p-6 border-brand-500/30 bg-brand-500/5 animate-fade-up">
          <div className="flex items-center gap-2 mb-5">
            <Bot className="w-5 h-5 text-brand-400" />
            <h2 className="text-lg font-semibold text-white">Recherche IA de prospects</h2>
          </div>

          {error && (
            <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-3 text-red-400 text-sm mb-4">
              {error}
            </div>
          )}

          <form onSubmit={handleAISearch} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm text-gray-300 mb-1.5">Nom de la campagne</label>
              <input value={form.campaignName} onChange={e => setForm({...form, campaignName: e.target.value})}
                className="input-dark" placeholder="Campagne SaaS France…" />
            </div>
            <div>
              <label className="block text-sm text-gray-300 mb-1.5">Secteur d'activité</label>
              <select value={form.industry} onChange={e => setForm({...form, industry: e.target.value})}
                className="input-dark">
                {INDUSTRIES.map(i => <option key={i} value={i}>{i}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm text-gray-300 mb-1.5">Pays cible</label>
              <select value={form.country} onChange={e => setForm({...form, country: e.target.value})}
                className="input-dark">
                {COUNTRIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm text-gray-300 mb-1.5">Plateforme</label>
              <select value={form.platform} onChange={e => setForm({...form, platform: e.target.value})}
                className="input-dark">
                {PLATFORMS.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm text-gray-300 mb-1.5">Mots-clés (optionnel)</label>
              <input value={form.keywords} onChange={e => setForm({...form, keywords: e.target.value})}
                className="input-dark" placeholder="startup, growth, B2B…" />
            </div>
            <div>
              <label className="block text-sm text-gray-300 mb-1.5">Nombre de prospects</label>
              <select value={form.count} onChange={e => setForm({...form, count: parseInt(e.target.value)})}
                className="input-dark">
                {[5, 10, 20, 50].map(n => <option key={n} value={n}>{n} prospects</option>)}
              </select>
            </div>
            <div className="md:col-span-2 lg:col-span-3 flex gap-3 pt-2">
              <button type="submit" disabled={searching} className="btn-primary flex items-center gap-2">
                {searching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Bot className="w-4 h-4" />}
                {searching ? 'Recherche en cours…' : 'Lancer la recherche IA'}
              </button>
              <button type="button" onClick={() => setShowForm(false)} className="btn-secondary">
                Annuler
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Filtres */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
            className="input-dark pl-10" placeholder="Rechercher un prospect…" />
        </div>
        <div className="flex gap-2 flex-wrap">
          {(['tous', 'nouveau', 'contacte', 'repondu', 'converti', 'ignore'] as FilterStatus[]).map(s => (
            <button key={s} onClick={() => setFilterStatus(s)}
              className={`px-3 py-2 rounded-xl text-xs font-medium transition-all ${filterStatus === s ? 'bg-brand-500/20 text-brand-400 border border-brand-500/30' : 'bg-dark-700 text-gray-400 hover:text-white border border-dark-400'}`}>
              {s === 'tous' ? 'Tous' : STATUS_LABELS[s]}
            </button>
          ))}
        </div>
      </div>

      {/* Table prospects */}
      <div className="card overflow-hidden">
        {loading ? (
          <div className="p-12 text-center">
            <Loader2 className="w-8 h-8 animate-spin text-brand-400 mx-auto mb-3" />
            <p className="text-gray-400">Chargement…</p>
          </div>
        ) : !filtered.length ? (
          <div className="p-12 text-center">
            <Search className="w-12 h-12 text-gray-600 mx-auto mb-3" />
            <p className="text-gray-400 font-medium">
              {searchQuery || filterStatus !== 'tous' ? 'Aucun résultat' : 'Aucun prospect'}
            </p>
            {!searchQuery && filterStatus === 'tous' && (
              <button onClick={() => setShowForm(true)} className="btn-primary inline-flex items-center gap-2 mt-4 text-sm">
                <Bot className="w-4 h-4" /> Lancer une recherche IA
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-dark-400">
                  {['Prospect', 'Entreprise', 'Contact', 'Secteur', 'Statut', 'Score', 'Actions'].map(h => (
                    <th key={h} className="text-left text-xs font-medium text-gray-500 uppercase tracking-wide px-4 py-3">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-dark-400/50">
                {filtered.map((p) => (
                  <tr key={p.id} className="hover:bg-dark-700/30 transition-colors group">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 bg-brand-500/10 rounded-full flex items-center justify-center text-brand-400 text-xs font-bold flex-shrink-0">
                          {p.full_name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0,2)}
                        </div>
                        <div>
                          <p className="font-medium text-white text-sm">{p.full_name}</p>
                          <p className="text-xs text-gray-500">{p.job_title}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-300">{p.company || '—'}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        {p.email && <a href={`mailto:${p.email}`} className="text-gray-400 hover:text-brand-400 transition-colors"><Mail className="w-4 h-4" /></a>}
                        {p.linkedin_url && <a href={p.linkedin_url} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-blue-400 transition-colors"><Linkedin className="w-4 h-4" /></a>}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-400">{p.industry}</td>
                    <td className="px-4 py-3">
                      <select value={p.status}
                        onChange={e => updateStatus(p.id, e.target.value)}
                        className="text-xs bg-dark-600 border border-dark-400 rounded-lg px-2 py-1 text-white focus:outline-none focus:border-brand-500">
                        {Object.entries(STATUS_LABELS).filter(([k]) => ['nouveau','contacte','repondu','converti','ignore'].includes(k)).map(([k,v]) => (
                          <option key={k} value={k}>{v}</option>
                        ))}
                      </select>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5">
                        <div className="w-16 h-1.5 bg-dark-600 rounded-full overflow-hidden">
                          <div className="h-full bg-brand-500 rounded-full" style={{ width: `${p.score}%` }} />
                        </div>
                        <span className="text-xs text-gray-400">{p.score}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => generateMessage(p)} title="Générer message"
                          className="p-1.5 rounded-lg text-gray-400 hover:text-brand-400 hover:bg-brand-500/10 transition-all">
                          <MessageSquare className="w-4 h-4" />
                        </button>
                        <button onClick={() => deleteProspect(p.id)} title="Supprimer"
                          className="p-1.5 rounded-lg text-gray-400 hover:text-red-400 hover:bg-red-500/10 transition-all">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {filtered.length > 0 && (
        <p className="text-xs text-gray-500 text-center">
          {filtered.length} prospect{filtered.length > 1 ? 's' : ''} affiché{filtered.length > 1 ? 's' : ''}
        </p>
      )}
    </div>
  );
}
