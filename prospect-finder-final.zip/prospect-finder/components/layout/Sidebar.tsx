'use client';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import {
  Target, LayoutDashboard, Users, MessageSquare,
  CreditCard, Settings, LogOut, Zap, Crown
} from 'lucide-react';
import { cn } from '@/lib/utils';
import type { Subscription } from '@/types';

const NAV = [
  { href: '/dashboard',   label: 'Tableau de bord', icon: LayoutDashboard },
  { href: '/prospects',   label: 'Prospects',        icon: Users },
  { href: '/messages',    label: 'Messages',         icon: MessageSquare },
  { href: '/billing',     label: 'Abonnement',       icon: CreditCard },
];

export default function Sidebar({
  user, subscription
}: {
  user: any;
  subscription: Subscription | null;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const supabase = createClient();

  async function handleLogout() {
    await supabase.auth.signOut();
    router.push('/auth/login');
  }

  const isPremium = subscription?.plan === 'premium' && subscription?.status === 'active';
  const isActive  = subscription?.status === 'active';

  return (
    <aside className="fixed left-0 top-0 h-full w-64 bg-dark-800 border-r border-dark-400 flex flex-col z-40">
      {/* Logo */}
      <div className="p-6 border-b border-dark-400">
        <Link href="/dashboard" className="flex items-center gap-2">
          <div className="w-9 h-9 bg-brand-500 rounded-xl flex items-center justify-center">
            <Target className="w-5 h-5 text-white" />
          </div>
          <span className="font-bold text-white text-lg">Prospect Finder</span>
        </Link>
      </div>

      {/* Plan badge */}
      {isActive && (
        <div className="mx-4 mt-4">
          <div className={cn(
            'flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold',
            isPremium ? 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20' : 'bg-brand-500/10 text-brand-400 border border-brand-500/20'
          )}>
            {isPremium ? <Crown className="w-3.5 h-3.5" /> : <Zap className="w-3.5 h-3.5" />}
            Plan {isPremium ? 'Premium' : 'Standard'} actif
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-1 mt-2">
        {NAV.map((item) => {
          const active = pathname === item.href || pathname.startsWith(item.href + '/');
          return (
            <Link key={item.href} href={item.href}
              className={cn(
                'flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200',
                active
                  ? 'bg-brand-500/10 text-brand-400 border border-brand-500/20'
                  : 'text-gray-400 hover:text-white hover:bg-dark-600'
              )}>
              <item.icon className="w-5 h-5 flex-shrink-0" />
              {item.label}
            </Link>
          );
        })}
      </nav>

      {/* Bottom */}
      <div className="p-4 border-t border-dark-400 space-y-1">
        <Link href="/dashboard/settings"
          className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-gray-400 hover:text-white hover:bg-dark-600 transition-all">
          <Settings className="w-5 h-5" />
          Paramètres
        </Link>
        <button onClick={handleLogout}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-gray-400 hover:text-red-400 hover:bg-red-500/10 transition-all">
          <LogOut className="w-5 h-5" />
          Déconnexion
        </button>
      </div>
    </aside>
  );
}
