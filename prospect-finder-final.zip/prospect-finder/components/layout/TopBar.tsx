'use client';
import { Bell, Search } from 'lucide-react';

export default function TopBar({ user, profile }: { user: any; profile: any }) {
  const name = profile?.full_name || user?.email?.split('@')[0] || 'Utilisateur';
  const initials = name.split(' ').map((n: string) => n[0]).join('').toUpperCase().slice(0, 2);

  return (
    <header className="h-16 border-b border-dark-400 bg-dark-800/50 backdrop-blur-sm flex items-center justify-between px-8 sticky top-0 z-30">
      <div className="flex items-center gap-3 flex-1 max-w-sm">
        <Search className="w-4 h-4 text-gray-500 flex-shrink-0" />
        <span className="text-sm text-gray-500">Recherche rapide…</span>
      </div>

      <div className="flex items-center gap-4">
        <button className="relative w-9 h-9 rounded-xl bg-dark-600 flex items-center justify-center text-gray-400 hover:text-white transition-colors">
          <Bell className="w-4 h-4" />
        </button>
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-brand-500 rounded-xl flex items-center justify-center text-white text-sm font-bold">
            {initials}
          </div>
          <div className="hidden md:block">
            <p className="text-sm font-medium text-white leading-none">{name}</p>
            <p className="text-xs text-gray-500 mt-0.5">{user?.email}</p>
          </div>
        </div>
      </div>
    </header>
  );
}
