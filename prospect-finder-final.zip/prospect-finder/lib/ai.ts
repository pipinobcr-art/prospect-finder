// lib/ai.ts — Services IA via Anthropic Claude
import Anthropic from '@anthropic-ai/sdk';

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY! });

// ─── Rechercher des prospects fictifs (simulation réaliste) ──
export async function aiSearchProspects({
  industry,
  country,
  platform,
  keywords,
  count = 10,
}: {
  industry: string;
  country: string;
  platform: string;
  keywords?: string[];
  count?: number;
}) {
  const prompt = `Tu es un expert en prospection B2B. Génère ${count} prospects réalistes (fictifs mais crédibles) dans le secteur "${industry}" en "${country}" pour la plateforme "${platform}".
${keywords?.length ? `Mots-clés : ${keywords.join(', ')}` : ''}

Retourne UNIQUEMENT un JSON valide (pas de markdown) avec ce format exact :
{
  "prospects": [
    {
      "full_name": "Prénom Nom",
      "email": "prenom.nom@entreprise.com",
      "company": "Nom Entreprise",
      "job_title": "Poste",
      "linkedin_url": "https://linkedin.com/in/profil",
      "website": "https://entreprise.com",
      "industry": "${industry}",
      "country": "${country}",
      "platform": "${platform}",
      "score": 85,
      "ai_summary": "Résumé en 1-2 phrases pourquoi ce prospect est pertinent"
    }
  ]
}`;

  const message = await anthropic.messages.create({
    model: 'claude-opus-4-20250514',
    max_tokens: 4000,
    messages: [{ role: 'user', content: prompt }],
  });

  const text = message.content[0].type === 'text' ? message.content[0].text : '';
  
  try {
    const clean = text.replace(/```json\n?|\n?```/g, '').trim();
    const parsed = JSON.parse(clean);
    return parsed.prospects || [];
  } catch {
    console.error('Erreur parsing IA prospects:', text);
    return [];
  }
}

// ─── Générer un message personnalisé ─────────────────────────
export async function aiGenerateMessage({
  prospect,
  channel,
  senderName,
  senderCompany,
  objective,
}: {
  prospect: {
    full_name: string;
    company?: string | null;
    job_title?: string | null;
    industry?: string | null;
    ai_summary?: string | null;
  };
  channel: 'email' | 'linkedin';
  senderName: string;
  senderCompany?: string;
  objective?: string;
}) {
  const isEmail = channel === 'email';
  const maxLength = isEmail ? '200 mots' : '150 mots';

  const prompt = `Tu es expert en copywriting B2B. Génère un message de prospection ${isEmail ? 'email' : 'LinkedIn'} personnalisé.

Prospect :
- Nom : ${prospect.full_name}
- Entreprise : ${prospect.company || 'N/A'}
- Poste : ${prospect.job_title || 'N/A'}
- Secteur : ${prospect.industry || 'N/A'}
- Contexte : ${prospect.ai_summary || 'N/A'}

Expéditeur : ${senderName}${senderCompany ? ` de ${senderCompany}` : ''}
Objectif : ${objective || 'Proposer une collaboration/démo'}

Le message doit être :
- Chaleureux et professionnel
- Personnalisé avec des détails spécifiques au prospect
- Maximum ${maxLength}
- Naturel, pas robotique
- Avec un appel à l'action clair

Retourne UNIQUEMENT un JSON valide :
${isEmail
  ? '{ "subject": "Objet de l\'email", "body": "Corps du message" }'
  : '{ "body": "Message LinkedIn" }'}`;

  const message = await anthropic.messages.create({
    model: 'claude-opus-4-20250514',
    max_tokens: 1000,
    messages: [{ role: 'user', content: prompt }],
  });

  const text = message.content[0].type === 'text' ? message.content[0].text : '';

  try {
    const clean = text.replace(/```json\n?|\n?```/g, '').trim();
    return JSON.parse(clean);
  } catch {
    return { subject: 'Message personnalisé', body: text };
  }
}

// ─── Générer messages en masse ────────────────────────────────
export async function aiBatchGenerateMessages(
  prospects: Array<{
    id: string;
    full_name: string;
    company?: string | null;
    job_title?: string | null;
    industry?: string | null;
    ai_summary?: string | null;
  }>,
  options: {
    channel: 'email' | 'linkedin';
    senderName: string;
    senderCompany?: string;
  }
) {
  const results = [];
  for (const prospect of prospects) {
    const msg = await aiGenerateMessage({ prospect, ...options });
    results.push({ prospect_id: prospect.id, ...msg });
  }
  return results;
}
