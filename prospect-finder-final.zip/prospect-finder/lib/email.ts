// lib/email.ts — Envoi d'emails via SMTP
import nodemailer from 'nodemailer';

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.gmail.com',
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

export async function sendEmail({
  to,
  subject,
  html,
  text,
}: {
  to: string;
  subject: string;
  html?: string;
  text?: string;
}) {
  const info = await transporter.sendMail({
    from: process.env.SMTP_FROM || 'Prospect Finder <noreply@prospectfinder.io>',
    to,
    subject,
    text,
    html: html || text,
  });
  return info;
}

export async function sendProspectEmail({
  toEmail,
  toName,
  subject,
  body,
}: {
  toEmail: string;
  toName: string;
  subject: string;
  body: string;
}) {
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
      ${body.split('\n').map(line => `<p style="margin: 0 0 12px; color: #333; line-height: 1.6;">${line}</p>`).join('')}
    </div>
  `;

  return sendEmail({ to: `${toName} <${toEmail}>`, subject, html, text: body });
}
