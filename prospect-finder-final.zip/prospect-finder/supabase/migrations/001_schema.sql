-- ============================================================
-- PROSPECT FINDER — Schéma complet Supabase
-- ============================================================

create extension if not exists "uuid-ossp";

-- ─── TYPES ───────────────────────────────────────────────────
create type subscription_plan   as enum ('standard', 'premium');
create type subscription_status as enum ('active', 'pending', 'past_due', 'canceled', 'trialing');
create type prospect_status     as enum ('nouveau', 'contacte', 'repondu', 'converti', 'ignore');
create type message_status      as enum ('brouillon', 'envoye', 'erreur');
create type message_channel     as enum ('email', 'linkedin');

-- ─── PROFILES ────────────────────────────────────────────────
create table public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  full_name   text,
  company     text,
  website     text,
  avatar_url  text,
  created_at  timestamptz default now(),
  updated_at  timestamptz default now()
);

alter table public.profiles enable row level security;
create policy "Lecture profil perso"    on public.profiles for select using (auth.uid() = id);
create policy "Mise à jour profil perso" on public.profiles for update using (auth.uid() = id);
create policy "Insertion profil perso"  on public.profiles for insert with check (auth.uid() = id);

-- ─── SUBSCRIPTIONS ───────────────────────────────────────────
create table public.subscriptions (
  id                  uuid primary key default uuid_generate_v4(),
  user_id             uuid not null references auth.users(id) on delete cascade,
  plan                subscription_plan   not null default 'standard',
  status              subscription_status not null default 'pending',
  mollie_customer_id  text,
  mollie_payment_id   text,
  mollie_mandate_id   text,
  current_period_start timestamptz,
  current_period_end   timestamptz,
  canceled_at          timestamptz,
  created_at           timestamptz default now(),
  updated_at           timestamptz default now()
);

alter table public.subscriptions enable row level security;
create policy "Lecture abonnement perso"    on public.subscriptions for select using (auth.uid() = user_id);
create policy "Insertion abonnement perso"  on public.subscriptions for insert with check (auth.uid() = user_id);
create policy "Mise à jour abonnement perso" on public.subscriptions for update using (auth.uid() = user_id);

-- ─── SEARCH CAMPAIGNS ────────────────────────────────────────
create table public.campaigns (
  id           uuid primary key default uuid_generate_v4(),
  user_id      uuid not null references auth.users(id) on delete cascade,
  name         text not null,
  industry     text not null,
  country      text not null,
  platform     text not null default 'email',
  keywords     text[],
  total_found  int default 0,
  status       text default 'active',
  created_at   timestamptz default now()
);

alter table public.campaigns enable row level security;
create policy "Campagnes perso" on public.campaigns for all using (auth.uid() = user_id);

-- ─── PROSPECTS ───────────────────────────────────────────────
create table public.prospects (
  id            uuid primary key default uuid_generate_v4(),
  user_id       uuid not null references auth.users(id) on delete cascade,
  campaign_id   uuid references public.campaigns(id) on delete set null,
  full_name     text not null,
  email         text,
  company       text,
  job_title     text,
  linkedin_url  text,
  website       text,
  industry      text,
  country       text,
  platform      text,
  status        prospect_status not null default 'nouveau',
  notes         text,
  score         int default 0,
  ai_summary    text,
  created_at    timestamptz default now(),
  updated_at    timestamptz default now()
);

alter table public.prospects enable row level security;
create policy "Prospects perso" on public.prospects for all using (auth.uid() = user_id);

-- ─── MESSAGES ────────────────────────────────────────────────
create table public.messages (
  id            uuid primary key default uuid_generate_v4(),
  user_id       uuid not null references auth.users(id) on delete cascade,
  prospect_id   uuid not null references public.prospects(id) on delete cascade,
  channel       message_channel not null default 'email',
  subject       text,
  body          text not null,
  status        message_status not null default 'brouillon',
  sent_at       timestamptz,
  error_message text,
  created_at    timestamptz default now()
);

alter table public.messages enable row level security;
create policy "Messages perso" on public.messages for all using (auth.uid() = user_id);

-- ─── TRIGGERS: updated_at ────────────────────────────────────
create or replace function update_updated_at()
returns trigger as $$
begin new.updated_at = now(); return new; end;
$$ language plpgsql;

create trigger profiles_updated_at     before update on public.profiles     for each row execute function update_updated_at();
create trigger subscriptions_updated_at before update on public.subscriptions for each row execute function update_updated_at();
create trigger prospects_updated_at    before update on public.prospects    for each row execute function update_updated_at();

-- ─── TRIGGER: créer profil à l'inscription ───────────────────
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, full_name, avatar_url)
  values (new.id, new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'avatar_url');
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();
