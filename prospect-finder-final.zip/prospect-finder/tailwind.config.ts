/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#f0fdf9", 100: "#ccfbef", 200: "#99f5df",
          300: "#5ce9c9", 400: "#2dd4b0", 500: "#14b897",
          600: "#0d9679", 700: "#0d7862", 800: "#0e5f4f",
          900: "#0e4e42", 950: "#052e27",
        },
        dark: {
          50: "#f7f7f8", 900: "#0a0a0f", 800: "#111118",
          700: "#18181f", 600: "#1f1f28", 500: "#27272f",
          400: "#3a3a45",
        },
      },
      fontFamily: {
        sans: ["var(--font-inter)", "system-ui", "sans-serif"],
        display: ["var(--font-cal)", "sans-serif"],
      },
      animation: {
        "fade-up": "fadeUp 0.5s ease forwards",
        "fade-in": "fadeIn 0.4s ease forwards",
        shimmer:   "shimmer 2s linear infinite",
        float:     "float 6s ease-in-out infinite",
        "spin-slow": "spin 8s linear infinite",
      },
      keyframes: {
        fadeUp:  { from: { opacity: "0", transform: "translateY(20px)" }, to: { opacity: "1", transform: "translateY(0)" } },
        fadeIn:  { from: { opacity: "0" }, to: { opacity: "1" } },
        shimmer: { from: { backgroundPosition: "-200% 0" }, to: { backgroundPosition: "200% 0" } },
        float:   { "0%,100%": { transform: "translateY(0)" }, "50%": { transform: "translateY(-8px)" } },
      },
    },
  },
  plugins: [],
};
