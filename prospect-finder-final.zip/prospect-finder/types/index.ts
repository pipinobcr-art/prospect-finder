export type SubscriptionPlan   = 'standard' | 'premium';
export type SubscriptionStatus = 'active' | 'pending' | 'past_due' | 'canceled' | 'trialing';
export type ProspectStatus     = 'nouveau' | 'contacte' | 'repondu' | 'converti' | 'ignore';
export type MessageStatus      = 'brouillon' | 'envoye' | 'erreur';
export type MessageChannel     = 'email' | 'linkedin';

export interface Profile {
  id: string;
  full_name: string | null;
  company: string | null;
  website: string | null;
  avatar_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface Subscription {
  id: string;
  user_id: string;
  plan: SubscriptionPlan;
  status: SubscriptionStatus;
  mollie_customer_id: string | null;
  mollie_payment_id: string | null;
  mollie_mandate_id: string | null;
  current_period_start: string | null;
  current_period_end: string | null;
  canceled_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface Campaign {
  id: string;
  user_id: string;
  name: string;
  industry: string;
  country: string;
  platform: string;
  keywords: string[] | null;
  total_found: number;
  status: string;
  created_at: string;
}

export interface Prospect {
  id: string;
  user_id: string;
  campaign_id: string | null;
  full_name: string;
  email: string | null;
  company: string | null;
  job_title: string | null;
  linkedin_url: string | null;
  website: string | null;
  industry: string | null;
  country: string | null;
  platform: string | null;
  status: ProspectStatus;
  notes: string | null;
  score: number;
  ai_summary: string | null;
  created_at: string;
  updated_at: string;
}

export interface Message {
  id: string;
  user_id: string;
  prospect_id: string;
  channel: MessageChannel;
  subject: string | null;
  body: string;
  status: MessageStatus;
  sent_at: string | null;
  error_message: string | null;
  created_at: string;
  prospect?: Prospect;
}

export interface PlanFeatures {
  name: string;
  price: number;
  prospects_per_month: number;
  messages_per_month: number;
  ai_search: boolean;
  auto_send: boolean;
  linkedin: boolean;
  priority_support: boolean;
}

export const PLANS: Record<SubscriptionPlan, PlanFeatures> = {
  standard: {
    name: 'Standard',
    price: 29,
    prospects_per_month: 100,
    messages_per_month: 50,
    ai_search: true,
    auto_send: false,
    linkedin: false,
    priority_support: false,
  },
  premium: {
    name: 'Premium',
    price: 79,
    prospects_per_month: 1000,
    messages_per_month: 500,
    ai_search: true,
    auto_send: true,
    linkedin: true,
    priority_support: true,
  },
};
